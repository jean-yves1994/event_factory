<div wire:ignore>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('event-item-selector');

$__html = app('livewire')->mount($__name, $__params, 'lw-2407044088-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div><?php /**PATH D:\event_factory\event_factory\resources\views/filament/forms/components/event-item-selector-wrapper.blade.php ENDPATH**/ ?>