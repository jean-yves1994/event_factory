<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Item Returns Report</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; text-align: left; }
        th { background-color: #eee; }
        .header-image {
            width: 100%;
            margin: 5px auto 10px auto; /* Small margin top and bottom */
            display: block;
        }
    </style>
</head>
<body>
    <h2>Item Returns Report</h2>
    <img src="<?php echo e(public_path('images/header.jpeg')); ?>" class="header-image" alt="Header Image">

    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Event</th>
                <th>Event Date</th>
                <th>Good</th>
                <th>Damaged</th>
                <th>Lost</th>
                <th>Returned On</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($r->item->name ?? '-'); ?></td>
                    <td><?php echo e($r->stockMovement->requisition->event->event_name ?? '-'); ?></td>
                    <td><?php echo e($r->stockMovement->requisition->event->event_date ?? '-'); ?></td>
                    <td><?php echo e($r->good_condition); ?></td>
                    <td><?php echo e($r->damaged_quantity); ?></td>
                    <td><?php echo e($r->lost_quantity); ?></td>
                    <td><?php echo e($r->created_at->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\event_factory\resources\views/exports/item-returns.blade.php ENDPATH**/ ?>