<div class="max-w-md-auto">
<h1>
    <div>
        <label for=""></label>
        <div>
            <select>
                <option value="">Select Category</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]--> 
            </select>
        </div>
    </div>
</h1>
</div><?php /**PATH D:\event_factory\event_factory\resources\views/livewire/item-selector.blade.php ENDPATH**/ ?>