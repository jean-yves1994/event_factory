<div wire:ignore>
    @livewire('event-item-selector')
</div>